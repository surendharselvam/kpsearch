/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
  }
  
  // Close the dropdown if the user clicks outside of it
  window.onclick = function(e) {
    if (!e.target.matches('.dropbtn')) {
    var myDropdown = document.getElementById("myDropdown");
      if (myDropdown && myDropdown.classList.contains('show')) {
        myDropdown.classList.remove('show');
      }
    }
  }
  function typeChanged(selectedValue){
    console.log(selectedValue);
    selectedType = selectedValue;
    //show input field
    //step 1 - hide all inputs
    $('.search_ip').hide();

    //step 2 - show only wrt dd option
    $('#dd_'+ selectedValue).show();

    $('.searchBtn').show();
    $('.searchBtn').unbind('click');

    $('.searchBtn').bind('click',handleHttpGetCall);
  }