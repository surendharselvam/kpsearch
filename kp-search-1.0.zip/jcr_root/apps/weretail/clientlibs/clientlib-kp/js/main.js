function handleHttpGetCall(){
    //prepare params
    var selector = "dd_"+selectedType + "_";
    var caseid = $('input[name="'+ selector + 'caseId"]')[0] && $('input[name="'+ selector + 'caseId"]')[0].value;
    var accnum = $('input[name="'+ selector +'accNum"]')[0].value;
    var year = $('input[name="'+ selector + 'year"]')[0].value;


    var paramsCollection = {
        case: `type=case&caseid=${caseid}&accnumber=${accnum}&year=${year}`,
        account: `type=Account&accnumber=${accnum}&year=${year}`
      };

    var url = paramsCollection[selectedType];
    
   console.log("Calling..:",url);

   $.get("http://localhost:3000/?"+ url, function(data){ 
       console.log(data);
       var filteredData = data;

       bindTemplate(filteredData);
    });

}

function handleHttpGetAllCall(){
  
   $.get("http://localhost:3000/all", function(data){ 
       console.log(data);
       var filteredData = data;
       bindTemplate(filteredData);
  
    });

}

function bindTemplate(filteredData){
    $('#clinicalTable').empty();
    $("#thTemplate").tmpl().appendTo("#clinicalTable");
    $("#MyTemplate").tmpl(filteredData).appendTo("#clinicalTable");
}

